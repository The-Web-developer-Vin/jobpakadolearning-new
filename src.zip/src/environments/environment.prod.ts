export const environment = {
  production: true,
  apiUrl: "https://learningbackend.jobpakado.com",
  apiVersion: "/api/v1",
};
