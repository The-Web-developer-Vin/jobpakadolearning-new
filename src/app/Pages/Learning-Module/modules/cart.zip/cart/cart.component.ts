import { Component, OnInit,Input, Output, EventEmitter } from '@angular/core';
import { courseService } from 'src/app/Pages/shared/services/courses/courses.service';
import { ToastrService } from 'ngx-toastr';
@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.scss']
})
export class CartComponent implements OnInit {
  @Input() cartLength: any;
  @Output() messageEvent = new EventEmitter<string>();
  userId: any;
  cartData: any;
  deleteCartId: any;
  priceData: any;
  cartTitle: any;
  cartName: any;
  length: any;
  deletyeLength: any;
  cartImage: any;
  offerPrice: any;
  totalPrice: any;
  offerCoupon:any
  offerTotalPrice: any;
  constructor(
    private courseService:courseService,
    private toastr: ToastrService

    ) { }

  ngOnInit(): void {
    // console.log("cartLength",this.cartLength);
    let userDetails:any = JSON.parse(localStorage.getItem("USERDATA") || '{}');
    // console.log("userDetails",userDetails)
    this.userId=userDetails._id;
    console.log("this.userId===>",this.userId)
    this.cartGetById();
  }

  cartGetById(){
    this.courseService.cartGetById(this.userId).subscribe((res:any)=>{
      console.log("cartGetById res",res);
      this.offerCoupon=1;
      this.cartData=res.data.cartId;
      this.deletyeLength=res.data.cartId.length;
      this.totalPrice=res.data.totalPrice;
      this.offerTotalPrice=this.totalPrice - this.offerCoupon;
      
      res.data.cartId.forEach((element:any) => {
      this.priceData=element.courseId.actualPrice,
      this.cartTitle=element.courseId.title,
      this.cartName=element.courseId.instructor?.name_as_per_bank,
      this.cartImage=element.courseId.image,
      this.offerPrice=element.courseId.offerPrice
      

      });
           console.log("this.cartData", this.priceData);
      
    },(err:any)=>{
      console.log("cratById err",err)
    })
  }
  deleteCartData(data:any){
    console.log("data",data);
    this.deleteCartId=data._id;

    this.courseService.deleteCart(this.deleteCartId).subscribe((res:any)=>{
      console.log("deleteCart res",res);
      this.toastr.success('Cart Item Deleted Sucessfully');
      // this.length=res.data.total
      this.cartGetById();
      this.courseService.sharedData.next(this.deletyeLength);

    },(err:any)=>{
      console.log("deleteCart err",err)
    })
  }

}
